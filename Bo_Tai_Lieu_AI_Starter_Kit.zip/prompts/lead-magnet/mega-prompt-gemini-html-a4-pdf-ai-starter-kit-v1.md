VAI TRÒ
Bạn là Senior Editorial Designer + Conversion Content Strategist + HTML Print Layout Specialist.

NHIỆM VỤ
Hãy tạo nội dung và mã HTML hoàn chỉnh cho TỪNG tài liệu trong bộ quà tặng:

"Bộ Bắt đầu với AI đúng cách"

Danh mục tài liệu gồm:
1. 01-cover-intro.html
2. 02-ai-level-checklist.html
3. 03-ai-learning-roadmap-by-goal.html
4. 04-ai-tools-to-start-with.html
5. 05-ai-7-day-kickstart-plan.html
6. 06-cta.html

MỤC TIÊU CHUNG
Tạo từng tài liệu dưới dạng HTML chuẩn A4, tối ưu để:
- đọc đẹp trên màn hình
- in hoặc export PDF đẹp
- rõ cấu trúc
- dễ hiểu với người mới
- public-facing
- phù hợp làm lead magnet chuyên nghiệp

BỐI CẢNH
Đây là bộ quà tặng dành cho người đang tìm hiểu AI nhưng chưa biết bắt đầu từ đâu.
Tài liệu này dùng cho:
- popup thoát trang
- lead magnet
- tặng sau khi điền form
- nuôi dưỡng lead đầu funnel

ĐỐI TƯỢNG ĐỌC
- Người mới bắt đầu với AI
- Người đã nghe nhiều về AI nhưng đang rối
- Người làm công việc văn phòng, kinh doanh, marketing, content, freelancer
- Người muốn ứng dụng AI thực tế nhưng không muốn bị overwhelm
- Không giả định họ có nền tảng kỹ thuật

ĐỊNH VỊ NỘI DUNG
Không viết như tài liệu kỹ thuật.
Không viết như nội dung nội bộ.
Không viết như blog lan man.
Phải viết như tài liệu hướng dẫn rõ ràng, chuyên nghiệp, thân thiện, thực dụng, giúp người đọc:
1. biết mình đang ở đâu
2. biết nên đi hướng nào
3. biết nên dùng tool gì trước
4. biết bước tiếp theo là gì

TONE OF VOICE
- Tiếng Việt tự nhiên, hiện đại, rõ ràng
- Chuyên nghiệp nhưng dễ đọc
- Có định hướng, không lên lớp
- Không dùng quá nhiều thuật ngữ khó
- Không hype, không khoa trương
- Không “dạy đời”
- Không biến thành sales page

YÊU CẦU QUAN TRỌNG
Mỗi tài liệu phải là 1 FILE HTML RIÊNG.
Mỗi file phải hoàn chỉnh, có thể lưu thành .html và mở trình duyệt để in ra PDF ngay.

KHÔNG được:
- gộp tất cả tài liệu vào một file duy nhất
- trả lời bằng markdown
- trả lời bằng outline nữa
- chỉ viết nội dung thô
- bỏ qua phần CSS
- bỏ qua tối ưu in PDF
- thêm các phần planning nội bộ như roadmap website, taxonomy, hub structure, routing logic nội bộ

OUTPUT BẮT BUỘC CHO MỖI FILE
Mỗi lần tạo một file, hãy trả ra duy nhất:
- tên file
- mô tả ngắn file dùng để làm gì
- toàn bộ mã HTML hoàn chỉnh

HTML phải bao gồm đầy đủ:
- <!DOCTYPE html>
- <html lang="vi">
- <head> với meta charset, viewport, title
- CSS nội bộ trong <style>
- <body> hoàn chỉnh
- Không phụ thuộc framework bên ngoài
- Không dùng Tailwind CDN
- Không dùng JS nếu không cần
- Dùng HTML + CSS thuần, sạch, gọn, chuẩn in PDF

CHUẨN THIẾT KẾ A4 PDF
Thiết kế theo khổ A4 dọc.

Thiết lập bắt buộc:
- @page size: A4
- margin hợp lý để in PDF đẹp
- font dễ đọc
- line-height thoáng
- hierarchy rõ giữa title / subtitle / heading / body / checklist / callout
- khoảng trắng tốt
- màu sắc tiết chế, premium, dễ in
- có thể dùng nền sáng hoặc nền rất nhạt để tối ưu PDF
- không dùng nền tối full trang
- không dùng hiệu ứng web không cần thiết

YÊU CẦU LAYOUT
Mỗi file nên có:
- cover/title area rõ ràng
- section heading rõ
- box / callout / checklist / table nếu phù hợp
- footer nhỏ gọn nếu cần
- đánh số trang bằng CSS nếu làm được đơn giản, còn không thì bỏ qua
- tránh chia trang xấu khi in

YÊU CẦU CSS PRINT
Phải tối ưu để export PDF:
- tránh vỡ layout
- tránh phần tử bị cắt giữa trang
- dùng break-inside: avoid cho box quan trọng
- heading không đứng cuối trang một mình
- checklist, cards, callout cần ổn định khi in
- nếu tài liệu dài nhiều trang, phải chia section hợp lý

PHONG CÁCH THIẾT KẾ
Định hướng:
- sạch
- hiện đại
- tinh tế
- giáo dục
- đáng tin
- không quá màu mè

Có thể dùng hệ màu gợi ý:
- text chính: #111827 hoặc gần tương đương
- text phụ: #4b5563
- line/border: #e5e7eb
- accent: đỏ trầm / xanh đậm / indigo nhẹ / emerald nhẹ
- box nền: #f8fafc hoặc #f9fafb

Không dùng:
- gradient lòe loẹt
- dark UI
- neon
- card effect nặng
- style landing page bán hàng

CẤU TRÚC NỘI DUNG TỪNG FILE

FILE 1 — 01-cover-intro.html
Mục tiêu:
Giới thiệu bộ tài liệu “Bộ Bắt đầu với AI đúng cách”

Phải có:
- tiêu đề chính
- phụ đề
- đoạn mở đầu ngắn giải thích vì sao người mới dễ bị overwhelm với AI
- 3 giá trị chính người đọc sẽ nhận được:
  1. xác định đúng level
  2. chọn đúng lộ trình
  3. chọn đúng tool để bắt đầu
- 1 section “Bộ này dành cho ai?”
- 1 section “Cách dùng bộ tài liệu này”
- 1 thông điệp chốt: không cần học tất cả, chỉ cần bắt đầu đúng
- trình bày đẹp như trang mở đầu tài liệu chuyên nghiệp

FILE 2 — 02-ai-level-checklist.html
Mục tiêu:
Giúp người đọc xác định level AI hiện tại

Phải có:
- tiêu đề rõ
- mô tả ngắn cách dùng checklist
- 4 level:
  - Level 1: Mới làm quen
  - Level 2: Biết dùng cơ bản
  - Level 3: Đã bắt đầu ứng dụng
  - Level 4: Muốn build hệ
- checklist 12–15 câu rõ ràng
- có thể trình bày dạng box tick
- có phần đọc kết quả:
  - nếu nghiêng về nhóm nào thì thuộc level nào
- mỗi level có block:
  - mô tả ngắn
  - điểm mạnh
  - rủi ro dễ gặp
  - ưu tiên tiếp theo

FILE 3 — 03-ai-learning-roadmap-by-goal.html
Mục tiêu:
Giúp người đọc chọn lộ trình học AI theo mục tiêu

Phải có:
- phần mở đầu giải thích: đừng chọn theo trend, hãy chọn theo mục tiêu
- 3 lộ trình chính:
  1. Dùng AI cho công việc hằng ngày
  2. Dùng AI cho kinh doanh / content / marketing
  3. Dùng AI để build hệ / automation / coding
- với mỗi lộ trình, cần có:
  - ai phù hợp
  - mục tiêu
  - nên học gì trước
  - kết quả mong đợi
  - sai lầm thường gặp
- thêm 1 bảng so sánh 3 lộ trình
- thêm 1 section “30 ngày đầu nên tập trung vào đâu?”

FILE 4 — 04-ai-tools-to-start-with.html
Mục tiêu:
Giảm overwhelm, giúp người đọc chọn bộ tool tối thiểu

Phải có:
- mở đầu ngắn: không cần nhiều tool
- nguyên tắc chọn tool lúc bắt đầu
- nhóm tool đề xuất:
  - text / tư duy / viết / lập kế hoạch
  - hình ảnh
  - giọng nói / audio
  - video / dựng nhanh
- nhắc đến các công cụ như:
  - ChatGPT
  - Gemini
  - Claude
  - ElevenLabs
  - Flow / Whisk / Canva AI
- trình bày dễ hiểu: tool nào hợp cho việc gì
- có section “stack tối thiểu” cho:
  - người mới
  - người làm content / business
  - người muốn build sâu
- có section “những lỗi chọn tool phổ biến”

FILE 5 — 05-ai-7-day-kickstart-plan.html
Mục tiêu:
Biến tài liệu thành hành động ngay trong 7 ngày

Phải có:
- tiêu đề rõ
- đoạn mở đầu ngắn
- kế hoạch 7 ngày, mỗi ngày 1 việc cụ thể
- mỗi ngày cần có:
  - mục tiêu
  - việc cần làm
  - kết quả mong đợi
- nên trình bày theo timeline / checklist / daily card
- có phần cuối:
  - sau 7 ngày, làm sao biết mình nên tiếp tục tự học hay cần tham gia chương trình phù hợp

FILE 6 — 06-cta.html
Mục tiêu:
Dẫn người đọc sang bước tiếp theo

Phải có:
- tiêu đề theo hướng định hướng, không sales quá mạnh
- 3 nhánh CTA:
  1. người mới bắt đầu
  2. người cần ứng dụng AI vào công việc / kinh doanh
  3. người muốn đi sâu build / automation / coding
- mỗi nhánh có:
  - mô tả ngắn
  - khi nào phù hợp
  - bước tiếp theo đề xuất
- có thể dùng card layout
- kết lại bằng thông điệp nhẹ nhàng, định hướng, chuyên nghiệp

YÊU CẦU VỀ CHẤT LƯỢNG NỘI DUNG
- Nội dung phải cụ thể
- Không được viết mơ hồ, rỗng
- Không dùng sáo ngữ
- Mỗi section phải thật sự giúp ích cho người mới
- Các ví dụ phải gần với thực tế công việc
- Tài liệu phải đọc xong là có thể hành động

YÊU CẦU VỀ UX WRITING
- headline ngắn, rõ
- subheading hỗ trợ hiểu nhanh
- bullet có ích
- checklist dễ dùng
- box kết luận dễ scan
- bố cục thân thiện với người đọc PDF

YÊU CẦU VỀ KỸ THUẬT HTML/CSS
- HTML semantic sạch
- CSS đặt trong <style>
- class rõ nghĩa
- không inline style trừ khi thực sự cần
- dùng max-width hợp lý
- dùng mm / cm / px hợp lý cho print
- test logic in PDF ngay từ đầu
- có class utility cho:
  - page
  - section
  - title
  - subtitle
  - lead
  - card
  - checklist
  - table
  - note
  - cta-box

QUY TRÌNH THỰC HIỆN
Làm lần lượt từng file.
Mỗi lần tôi yêu cầu một file, bạn chỉ tạo đúng file đó.

Khi tạo file, format trả lời phải là:

1. Tên file: [tên file]
2. Mục đích: [1-2 câu]
3. HTML hoàn chỉnh:
[code html đầy đủ]

KHÔNG thêm giải thích dài dòng ngoài nội dung cần thiết.

BẮT ĐẦU
Trước tiên hãy tạo file:
01-cover-intro.html